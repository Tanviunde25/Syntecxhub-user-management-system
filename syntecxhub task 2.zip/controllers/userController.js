// Show Add User Form
exports.addUserForm = (req, res) => {
  res.render("users/add");
};

// Create / Save New User
exports.createUser = async (req, res) => {
  try {
    await User.create(req.body);
    res.redirect("/");
  } catch (err) {
    res.status(400).send("Error saving user: " + err.message);
  }
};
