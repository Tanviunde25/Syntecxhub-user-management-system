const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const controller = require("../controllers/userController");

router.get("/", auth, controller.getUsers);
router.get("/add", auth, controller.addUserForm);
router.post("/add", auth, controller.createUser);
router.get("/edit/:id", auth, controller.editUserForm);
router.post("/edit/:id", auth, controller.updateUser);
router.get("/delete/:id", auth, controller.deleteUser);

module.exports = router;
