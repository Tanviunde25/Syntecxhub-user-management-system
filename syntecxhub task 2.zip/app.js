const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
require("./config/db");

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));

app.use("/", require("./routes/userRoutes"));

app.listen(4000, () => {
  console.log("Server running on http://localhost:4000");
});

